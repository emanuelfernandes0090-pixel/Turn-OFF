import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Gemini OCR / Bill Scan endpoint
app.post("/api/scan-bill", async (req, res) => {
  console.log("[server] Received /api/scan-bill request:", {
    hasBase64: !!req.body?.base64,
    hasRawText: !!req.body?.rawText,
    mimeType: req.body?.mimeType
  });
  try {
    const { base64, mimeType, rawText } = req.body;

    // If client supplied raw text or no image base64, respond with text analysis or error
    if (!base64 && !rawText) {
      res.status(400).json({ error: "Nenhum arquivo ou texto foi fornecido para análise." });
      return;
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && (base64 || rawText)) {
      try {
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: {
            headers: {
              "User-Agent": "aistudio-build",
            },
          },
        });

        const prompt = `Você é um perito em análise e conferência de contas de energia elétrica do Brasil (Enel, Neoenergia, CPFL, Cemig, Copel, Equatorial, Celesc, Energisa, Light, etc.).
Analise a fatura de energia fornecida e extraia com RIGOR ABSOLUTO os dados.

REGRAS DE CONFIABILIDADE (ERRAR PARA VAZIO É MELHOR QUE ERRAR PARA NÚMERO INCORRETO):
1. 'consumo_kwh': Apenas o consumo FATURADO em kWh do ciclo atual. NUNCA confunda com histórico de 12 meses, média, leitura anterior, leitura atual do medidor ou consumo injetado. Se não tiver certeza, retorne null.
2. 'valor_total': O valor final a pagar em reais (R$). NUNCA confunda com tensão nominal (ex: 127V ou 220V), código de barras, código do cliente ou valor de impostos isolados.
3. 'mes_referencia': Mês de referência (ex: "08/2026", "Agosto/2026", "11/2017").
4. 'vencimento': Data de vencimento no formato DD/MM/AAAA.
5. 'distribuidora': Nome da concessionária (ex: Celesc, Cemig, Enel, Neoenergia, Equatorial, etc.).
6. 'unidade_consumidora': Código do cliente ou UC.
7. 'tarifa_te': Tarifa de Energia (R$/kWh), se identificada.
8. 'tarifa_tusd': Tarifa de Uso do Sistema de Distribuição (R$/kWh), se identificada.
9. 'bandeira': Cor da bandeira tarifária: "verde", "amarela", "vermelha_1", "vermelha_2", ou null.
10. 'valor_bandeira': Adicional em R$ cobrado pela bandeira tarifária, se houver.
11. 'impostos': { icms: R$ ou null, pis_cofins: R$ ou null }.
12. 'cosip': Valor da taxa de iluminação pública (COSIP/CIP) em R$ ou null.
13. 'tarifa_social_identificada': true somente se a fatura explicitamente contiver "Tarifa Social", "Baixa Renda", "TSEE" ou desconto social. Caso contrário false.
14. 'geracao_distribuida': { energia_injetada_kwh: número ou null, creditos_acumulados_kwh: número ou null } ou null.
15. 'alertas': lista de strings com avisos relevantes (ex: "Consumo alto", "Bandeira vermelha", "Tarifa Social identificada").
16. 'campos_baixa_confianca': lista de nomes de campos onde houve dúvida ou baixa nitidez.

Responda EXCLUSIVAMENTE em formato JSON com esta estrutura exata, sem blocos markdown ou texto adicional:
{
  "distribuidora": string | null,
  "unidade_consumidora": string | null,
  "mes_referencia": string | null,
  "vencimento": string | null,
  "consumo_kwh": number | null,
  "consumo_medio_12m_kwh": number | null,
  "valor_total": number | null,
  "bandeira": "verde" | "amarela" | "vermelha_1" | "vermelha_2" | null,
  "valor_bandeira": number | null,
  "tarifa_te": number | null,
  "tarifa_tusd": number | null,
  "impostos": { "icms": number | null, "pis_cofins": number | null },
  "cosip": number | null,
  "tarifa_social_identificada": boolean,
  "geracao_distribuida": { "energia_injetada_kwh": number | null, "creditos_acumulados_kwh": number | null } | null,
  "alertas": string[],
  "campos_baixa_confianca": string[]
}`;

        // Build parts for multimodal or text input
        const parts: any[] = [];
        if (base64) {
          const cleanBase64 = base64.replace(/^data:[^;]+;base64,/, "");
          parts.push({
            inlineData: {
              mimeType: mimeType || "image/jpeg",
              data: cleanBase64,
            },
          });
        }
        if (rawText) {
          parts.push({
            text: `Texto da fatura:\n${rawText}`,
          });
        }
        parts.push({ text: prompt });

        // Try primary model gemini-3.8-flash, with fallback to gemini-3.6-flash
        const modelsToTry = ["gemini-3.8-flash", "gemini-3.6-flash"];
        let parsedData: any = null;
        let lastError: any = null;

        for (const model of modelsToTry) {
          try {
            console.log(`[server] Tentando extração OCR com modelo: ${model}`);
            const response = await ai.models.generateContent({
              model,
              contents: { parts },
              config: {
                thinkingConfig: { thinkingBudget: 0 },
                maxOutputTokens: 4096,
              },
            });

            const candidate = response.candidates?.[0];
            const finishReason = candidate?.finishReason;
            const contentText = response.text || "";

            if (finishReason === "MAX_TOKENS" || !contentText.trim()) {
              console.warn(
                `[server] Modelo ${model} retornou resposta incompleta ou vazia (finishReason: ${finishReason}). Tentando próximo modelo.`
              );
              continue;
            }

            // Clean JSON from code blocks if any
            const jsonMatch = contentText.match(/\{[\s\S]*\}/);
            const cleanedJson = jsonMatch
              ? jsonMatch[0]
              : contentText.replace(/^```json\s*/i, "").replace(/```\s*$/i, "").trim();

            try {
              parsedData = JSON.parse(cleanedJson);
              if (parsedData && typeof parsedData === "object") {
                console.log(`[server] Sucesso ao parsear JSON com modelo ${model}`);
                break;
              }
            } catch (jsonErr) {
              console.warn(`[server] Modelo ${model} gerou JSON inválido, tentando próximo modelo:`, jsonErr);
              lastError = jsonErr;
              continue;
            }
          } catch (modelErr) {
            lastError = modelErr;
            console.warn(`[server] Erro na chamada do modelo ${model}, tentando próximo:`, modelErr);
          }
        }

        if (parsedData) {
          res.json({
            source: "gemini_vision",
            bill: parsedData,
            success: true,
          });
          return;
        }

        if (lastError) {
          throw lastError;
        }
      } catch (geminiError) {
        console.warn("[server] Gemini OCR fallback triggered:", geminiError);
        // Fall through to fallback
      }
    }

    // Fallback response for offline or when Gemini key is not provided
    res.json({
      source: "client_fallback",
      message: "Análise por IA indisponível ou em modo offline. Use o extrator determinístico local ou preenchimento manual.",
      success: false,
    });
  } catch (error) {
    console.error("[server] Erro no processamento de fatura:", error);
    res.status(500).json({ error: "Falha ao processar arquivo da conta de energia." });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

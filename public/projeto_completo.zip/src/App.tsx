import React, { useState, useEffect } from "react";
import {
  Header,
} from "./components/Header";
import {
  HomeDashboard,
} from "./components/HomeDashboard";
import {
  BillScanner,
} from "./components/BillScanner";
import {
  DiagnosisWizard,
} from "./components/DiagnosisWizard";
import {
  WhatIfSimulator,
} from "./components/WhatIfSimulator";
import {
  TarifaSocialGuide,
} from "./components/TarifaSocialGuide";
import {
  SafetyGuide,
} from "./components/SafetyGuide";
import {
  LearningGuide,
} from "./components/LearningGuide";
import {
  EquipmentPaybackSimulator,
} from "./components/EquipmentPaybackSimulator";
import {
  HistoryView,
} from "./components/HistoryView";
import {
  AccessibilityModal,
} from "./components/AccessibilityModal";
import {
  BottomNav,
} from "./components/BottomNav";
import {
  OnboardingModal,
} from "./components/OnboardingModal";
import {
  ShareModal,
  SharePayload,
} from "./components/ShareModal";
import {
  AppTab,
  AccessibilitySettings,
  SavedDiagnosis,
  BillScanRecord,
  ExtractedBill,
} from "./types";
import {
  loadAccessibilitySettings,
  saveAccessibilitySettings,
  loadDiagnoses,
  saveDiagnoses,
  loadBillScans,
  saveBillScans,
  saveBillScan,
  loadPlanProgress,
} from "./lib/storage";
import {
  speakText,
  stopSpeech,
  isSpeechSupported,
} from "./lib/speech";
import {
  CheckCircle2,
  Info,
  Volume2,
  VolumeX,
} from "lucide-react";

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<AppTab>("home");

  // Persistent storage states
  const [settings, setSettings] = useState<AccessibilitySettings>(() =>
    loadAccessibilitySettings()
  );
  const [diagnoses, setDiagnoses] = useState<SavedDiagnosis[]>(() =>
    loadDiagnoses()
  );
  const [billScans, setBillScans] = useState<BillScanRecord[]>(() =>
    loadBillScans()
  );
  const [planProgress, setPlanProgress] = useState<string[]>(() =>
    loadPlanProgress()
  );

  // Cross-view state passings
  const [selectedBillForDiagnosis, setSelectedBillForDiagnosis] = useState<BillScanRecord | null>(null);
  const [activeSimulatorBaseline, setActiveSimulatorBaseline] = useState<SavedDiagnosis | null>(null);

  // Modal and TTS states
  const [isAccessModalOpen, setIsAccessModalOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(() => {
    if (typeof window === "undefined") return false;
    return !localStorage.getItem("turnoff:tutorial_seen:v2");
  });
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [sharePayload, setSharePayload] = useState<SharePayload | null>(null);
  const [selectedDiagnosisForShare, setSelectedDiagnosisForShare] = useState<SavedDiagnosis | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Show Toast
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Close tutorial and remember preference
  const handleCloseOnboarding = () => {
    setIsOnboardingOpen(false);
    try {
      localStorage.setItem("turnoff:tutorial_seen:v2", "true");
    } catch {
      // ignore
    }
  };

  // Sync settings with document classes and CSS custom variables
  useEffect(() => {
    const root = document.documentElement;

    // Theme (dark mode)
    if (settings.theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }

    // High contrast
    if (settings.highContrast) {
      root.classList.add("high-contrast");
    } else {
      root.classList.remove("high-contrast");
    }

    // Dynamic Font Scaling
    const scale = settings.fontScale || 1.0;
    root.style.setProperty("--app-font-scale", `${Math.round(scale * 100)}%`);

    saveAccessibilitySettings(settings);
  }, [settings]);

  // Robust theme toggler ensuring immediate DOM reaction
  const handleToggleTheme = () => {
    const nextTheme: "light" | "dark" = settings.theme === "dark" ? "light" : "dark";
    const updated: AccessibilitySettings = { ...settings, theme: nextTheme };
    setSettings(updated);
    saveAccessibilitySettings(updated);
    if (nextTheme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    showToast(nextTheme === "dark" ? "Modo escuro ativado." : "Modo claro ativado.");
  };

  // Sync diagnoses
  const handleSaveDiagnosis = (newDiagnosis: SavedDiagnosis) => {
    const updated = [newDiagnosis, ...diagnoses.filter((d) => d.id !== newDiagnosis.id)];
    setDiagnoses(updated);
    saveDiagnoses(updated);
    showToast("Diagnóstico registrado e salvo no histórico com sucesso!");
  };

  // Delete diagnosis
  const handleDeleteDiagnosis = (id: string) => {
    const updated = diagnoses.filter((d) => d.id !== id);
    setDiagnoses(updated);
    saveDiagnoses(updated);
    showToast("Diagnóstico removido.");
  };

  // Sync bill scans with automatic anomaly & goal evaluation
  const handleSaveBill = (bill: ExtractedBill) => {
    saveBillScan(bill);
    setBillScans(loadBillScans());
    showToast("Fatura salva no histórico com sucesso!");
  };

  // Delete bill
  const handleDeleteBill = (id: string) => {
    const updated = billScans.filter((b) => b.id !== id);
    setBillScans(updated);
    saveBillScans(updated);
    showToast("Fatura removida.");
  };

  // Clear all data
  const handleClearAllData = () => {
    setDiagnoses([]);
    setBillScans([]);
    saveDiagnoses([]);
    saveBillScans([]);
    showToast("Todos os dados salvos foram apagados.");
  };

  // Refresh from imported file
  const handleDataImported = () => {
    setDiagnoses(loadDiagnoses());
    setBillScans(loadBillScans());
    setSettings(loadAccessibilitySettings());
    showToast("Backup importado com sucesso!");
  };

  // Action from Scanner -> Open in Diagnosis Wizard
  const handleUseBillInDiagnosis = (bill: ExtractedBill) => {
    const record = saveBillScan(bill);
    setBillScans(loadBillScans());
    setSelectedBillForDiagnosis(record);
    setActiveTab("diagnosis");
    showToast("Dados da fatura carregados no assistente de diagnóstico.");
  };

  // Action from Diagnosis -> Open in What-If Simulator
  const handleOpenSimulator = (diagnosis: SavedDiagnosis) => {
    setActiveSimulatorBaseline(diagnosis);
    setActiveTab("simulator");
  };

  // Action from History -> Open diagnosis
  const handleSelectDiagnosisFromHistory = (diag: SavedDiagnosis) => {
    if (diag.kind === "teste") {
      setActiveSimulatorBaseline(diag);
      setActiveTab("simulator");
    } else {
      setActiveSimulatorBaseline(diag);
      setActiveTab("diagnosis");
    }
  };

  // Action from History -> Open bill
  const handleSelectBillFromHistory = (billRecord: BillScanRecord) => {
    setSelectedBillForDiagnosis(billRecord);
    setActiveTab("diagnosis");
  };

  // Text-To-Speech read aloud for active view
  const toggleSpeechCurrentView = () => {
    if (isSpeaking) {
      stopSpeech();
      setIsSpeaking(false);
      return;
    }

    let textToSpeak = "";
    if (activeTab === "home") {
      textToSpeak = "Você está na tela inicial do Turn OFF. Aqui você pode escanear sua conta de luz, iniciar um diagnóstico detalhado dos aparelhos da sua casa, simular economia e conferir seu direito à Tarifa Social.";
    } else if (activeTab === "scanner") {
      textToSpeak = "Leitor de faturas de energia. Envie uma foto ou PDF da sua conta para conferência automática dos valores de consumo em quilowatts-hora, total a pagar e bandeira tarifária.";
    } else if (activeTab === "diagnosis") {
      textToSpeak = "Diagnóstico residencial de energia. Preencha os aparelhos da sua casa para calcular onde está o maior gasto e receber recomendações personalizadas.";
    } else if (activeTab === "simulator") {
      textToSpeak = "Simulador E se. Teste mudanças como diminuir o banho, trocar lâmpadas por LED ou regular a temperatura do ar-condicionado.";
    } else if (activeTab === "tarifa-social") {
      textToSpeak = "Guia da Tarifa Social de Energia Elétrica. Famílias cadastradas no CadÚnico têm gratuidade de 100% no consumo de até 80 quilowatts-hora por mês.";
    } else if (activeTab === "safety") {
      textToSpeak = "Guia de Segurança Elétrica Residencial. Atenção para tomadas aquecidas, cheiro de queimado ou disjuntores desarmando. Economizar energia nunca deve arriscar a segurança da sua casa.";
    } else if (activeTab === "history") {
      textToSpeak = "Histórico de diagnósticos e faturas salvas. Acompanhe a evolução do seu consumo ao longo dos meses.";
    }

    if (textToSpeak) {
      setIsSpeaking(true);
      speakText(textToSpeak, settings, () => setIsSpeaking(false));
    }
  };

  // Pick the latest primary diagnosis for the simulator if none manually selected
  const defaultSimulatorBaseline =
    activeSimulatorBaseline ||
    diagnoses.find((d) => d.kind !== "teste") ||
    diagnoses[0] ||
    null;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-['Inter',sans-serif] selection:bg-emerald-500 selection:text-white transition-colors duration-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 p-4 rounded-2xl bg-emerald-700 text-white shadow-xl flex items-center gap-2 text-xs sm:text-sm font-bold animate-in slide-in-from-top-4 duration-300">
          <CheckCircle2 className="w-5 h-5 text-emerald-200 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Header */}
      <Header
        activeTab={activeTab}
        currentTab={activeTab}
        onSelectTab={setActiveTab}
        theme={settings.theme}
        onToggleTheme={handleToggleTheme}
        onOpenAccessibility={() => setIsAccessModalOpen(true)}
        onOpenTutorial={() => setIsOnboardingOpen(true)}
        onOpenShare={() => {
          setSelectedDiagnosisForShare(defaultSimulatorBaseline);
          setIsShareModalOpen(true);
        }}
        settings={settings}
      />

      {/* Floating Read Aloud Button if speech synthesis supported - lifted above bottom nav */}
      {isSpeechSupported() && (
        <div className="fixed bottom-20 sm:bottom-22 right-4 sm:right-6 z-30 no-print">
          <button
            id="btn-floating-tts"
            onClick={toggleSpeechCurrentView}
            className={`p-3.5 rounded-full shadow-lg transition-all flex items-center gap-2 text-xs font-bold ${
              isSpeaking
                ? "bg-amber-600 text-white animate-pulse"
                : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-100"
            }`}
            title={isSpeaking ? "Pausar leitura de tela" : "Ouvir resumo desta tela em áudio"}
          >
            {isSpeaking ? (
              <>
                <VolumeX className="w-5 h-5 text-white" />
                <span className="hidden sm:inline">Parar Leitura</span>
              </>
            ) : (
              <>
                <Volume2 className="w-5 h-5 text-emerald-600" />
                <span className="hidden sm:inline">Ouvir Tela</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Main Content Area with bottom padding for fixed BottomNav */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-28">
        {activeTab === "home" && (
          <HomeDashboard
            diagnoses={diagnoses}
            billScans={billScans}
            completedActions={planProgress}
            onNavigate={setActiveTab}
            onOpenTutorial={() => setIsOnboardingOpen(true)}
            settings={settings}
          />
        )}

        {activeTab === "scanner" && (
          <BillScanner
            onSaveBill={handleSaveBill}
            onUseInDiagnosis={handleUseBillInDiagnosis}
            settings={settings}
          />
        )}

        {activeTab === "diagnosis" && (
          <DiagnosisWizard
            onSaveDiagnosis={handleSaveDiagnosis}
            onOpenSimulator={handleOpenSimulator}
            billScans={billScans}
            initialBillScan={selectedBillForDiagnosis}
            settings={settings}
          />
        )}

        {activeTab === "simulator" && (
          <WhatIfSimulator
            baselineDiagnosis={defaultSimulatorBaseline}
            onSaveTestSimulation={handleSaveDiagnosis}
            onShareSimulation={(scenario) => {
              setSharePayload({
                type: "simulation",
                baseline: defaultSimulatorBaseline,
                scenario,
              });
              setIsShareModalOpen(true);
            }}
            settings={settings}
          />
        )}

        {activeTab === "payback" && (
          <EquipmentPaybackSimulator
            settings={settings}
            onSharePayback={(payload) => {
              setSharePayload({
                type: "payback",
                equipmentName: payload.equipmentName,
                investmentCost: payload.investmentBrl,
                monthlySavings: payload.monthlySavingsBrl,
                annualSavings: payload.annualSavingsBrl,
                paybackMonths: payload.paybackMonths,
                return5Years: payload.monthlySavingsBrl * 60 - payload.investmentBrl,
                viable: payload.viable,
              });
              setIsShareModalOpen(true);
            }}
          />
        )}

        {activeTab === "safety" && (
          <SafetyGuide settings={settings} />
        )}

        {activeTab === "learn" && (
          <LearningGuide settings={settings} />
        )}

        {activeTab === "tarifa-social" && (
          <TarifaSocialGuide settings={settings} />
        )}

        {activeTab === "history" && (
          <HistoryView
            diagnoses={diagnoses}
            billScans={billScans}
            onSelectDiagnosis={handleSelectDiagnosisFromHistory}
            onSelectBill={handleSelectBillFromHistory}
            onDeleteDiagnosis={handleDeleteDiagnosis}
            onDeleteBill={handleDeleteBill}
            onClearAll={handleClearAllData}
            onDataImported={handleDataImported}
            onOpenShare={(diag) => {
              setSelectedDiagnosisForShare(diag || defaultSimulatorBaseline);
              setIsShareModalOpen(true);
            }}
            settings={settings}
          />
        )}
      </main>

      {/* Fixed Bottom Navigation (Original App Standard) */}
      <BottomNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        savedDiagnosisCount={diagnoses.length}
        savedBillsCount={billScans.length}
      />

      {/* Guided Tutorial Onboarding Modal */}
      <OnboardingModal
        isOpen={isOnboardingOpen}
        onClose={handleCloseOnboarding}
        onNavigateToTab={setActiveTab}
      />

      {/* Share and PDF Export Modal */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => {
          setIsShareModalOpen(false);
          setSharePayload(null);
        }}
        payload={sharePayload}
        latestDiagnosis={selectedDiagnosisForShare || defaultSimulatorBaseline}
      />

      {/* Accessibility Preferences Modal */}
      <AccessibilityModal
        isOpen={isAccessModalOpen}
        onClose={() => setIsAccessModalOpen(false)}
        settings={settings}
        onSaveSettings={(newSettings) => {
          setSettings(newSettings);
          saveAccessibilitySettings(newSettings);
        }}
        onClearData={handleClearAllData}
        onOpenTutorial={() => setIsOnboardingOpen(true)}
      />

      {/* Footer with Technical Standards & Disclaimer */}
      <footer className="border-t border-slate-200 dark:border-slate-800/80 bg-white dark:bg-slate-900 py-8 mt-12 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <div className="space-y-1 text-center sm:text-left">
            <p className="font-bold text-slate-700 dark:text-slate-300">
              Turn OFF — Eficiência Energética Residencial
            </p>
            <p className="text-[11px]">
              Desenvolvido com cálculos físicos auditáveis, alinhado às diretrizes da ANEEL, Procel e NBR 5410.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-[11px]">
            <button
              onClick={() => setActiveTab("safety")}
              className="hover:text-emerald-600 transition underline"
            >
              Segurança Elétrica
            </button>
            <button
              onClick={() => setActiveTab("tarifa-social")}
              className="hover:text-emerald-600 transition underline"
            >
              Tarifa Social (TSEE)
            </button>
            <button
              onClick={() => setIsAccessModalOpen(true)}
              className="hover:text-emerald-600 transition underline"
            >
              Acessibilidade & Fala
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

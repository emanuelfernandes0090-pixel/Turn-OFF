import React from "react";
import {
  Zap,
  Moon,
  Sun,
  Sliders,
  Sparkles,
  HelpCircle,
  Share2,
  Volume2,
  Play,
  Pause,
  Square,
  BookOpen,
} from "lucide-react";
import { AccessibilitySettings, AppTab } from "../types";
import { speechManager, TAB_NARRATIONS } from "../lib/speech";

interface HeaderProps {
  currentTab?: AppTab | string;
  activeTab?: AppTab | string;
  onSelectTab: (tab: AppTab) => void;
  theme?: "light" | "dark";
  onToggleTheme?: () => void;
  onOpenAccessibility: () => void;
  onOpenTutorial?: () => void;
  onOpenShare: () => void;
  settings?: AccessibilitySettings;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  activeTab,
  onSelectTab,
  theme = "light",
  onToggleTheme,
  onOpenAccessibility,
  onOpenTutorial,
  onOpenShare,
  settings,
}) => {
  const [speechState, setSpeechState] = React.useState(speechManager.getState());
  const effectiveTab: AppTab = (activeTab || currentTab || "home") as AppTab;

  React.useEffect(() => {
    return speechManager.subscribe((state) => {
      setSpeechState(state);
    });
  }, []);

  const handlePlayVoice = () => {
    const narration = TAB_NARRATIONS[effectiveTab] || TAB_NARRATIONS.inicio;
    const isDetailed = settings?.speechGuide?.mode === "detalhado";
    const text = isDetailed
      ? `${narration.title}. ${narration.detailed}`
      : `${narration.title}. ${narration.short}`;
    speechManager.speak(text, {
      rate: settings?.speechGuide?.rate ?? 1.0,
      volume: settings?.speechGuide?.volume ?? 1.0,
    });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors no-print">
      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo Brand */}
          <button
            id="nav-logo"
            onClick={() => onSelectTab("home")}
            className="flex items-center gap-2.5 sm:gap-3 group focus:outline-hidden text-left"
            title="Ir para o Início"
          >
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-tr from-emerald-700 to-teal-500 text-white flex items-center justify-center shadow-md shadow-emerald-700/20 group-hover:scale-105 transition-transform">
              <Zap className="w-5 h-5 fill-white stroke-none" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white font-['Space_Grotesk']">
                  Turn <span className="text-emerald-600 dark:text-emerald-400">OFF</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                  v2.5
                </span>
              </div>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 hidden sm:block">
                Eficiência Energética & Segurança Residencial
              </p>
            </div>
          </button>

          {/* Action Buttons Right */}
          <div className="flex items-center gap-1 sm:gap-2">
            {/* Voice Guide Quick Player (ONLY shown if enabled in settings) */}
            {settings?.speechGuide?.enabled && (
              <div className="flex items-center gap-1 bg-emerald-50 dark:bg-emerald-950/60 p-1 rounded-2xl border border-emerald-200 dark:border-emerald-800">
                {!speechState.isSpeaking ? (
                  <button
                    id="btn-voice-header-play"
                    onClick={handlePlayVoice}
                    className="px-2.5 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-bold flex items-center gap-1 hover:bg-emerald-700 transition"
                    title="Ouvir explicação em áudio desta tela"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Ouvir Tela</span>
                  </button>
                ) : (
                  <>
                    <button
                      id="btn-voice-header-pause-resume"
                      onClick={() =>
                        speechState.isPaused
                          ? speechManager.resume()
                          : speechManager.pause()
                      }
                      className="p-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 transition"
                      title={speechState.isPaused ? "Retomar" : "Pausar"}
                    >
                      {speechState.isPaused ? (
                        <Play className="w-3.5 h-3.5 fill-current" />
                      ) : (
                        <Pause className="w-3.5 h-3.5 fill-current" />
                      )}
                    </button>
                    <button
                      id="btn-voice-header-stop"
                      onClick={() => speechManager.stop()}
                      className="p-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-300 transition"
                      title="Parar áudio"
                    >
                      <Square className="w-3.5 h-3.5 fill-current" />
                    </button>
                  </>
                )}
              </div>
            )}

            {/* Share Button */}
            <button
              id="btn-header-share"
              onClick={onOpenShare}
              className="p-2 sm:px-3 sm:py-2 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition flex items-center gap-1.5 text-xs font-bold"
              title="Compartilhar Aplicativo / Diagnóstico"
              aria-label="Compartilhar Aplicativo"
            >
              <Share2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span className="hidden md:inline">Compartilhar</span>
            </button>

            {/* Accessibility Button */}
            <button
              id="btn-open-accessibility"
              onClick={onOpenAccessibility}
              className="p-2 sm:px-3 sm:py-2 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition flex items-center gap-1.5 text-xs font-bold"
              title="Configurações de Acessibilidade e Tamanho da Fonte"
              aria-label="Ajustar tamanho da fonte e acessibilidade"
            >
              <Sliders className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span className="hidden md:inline">Acessibilidade</span>
            </button>

            {/* Theme Toggle Button */}
            <button
              id="btn-toggle-theme"
              onClick={onToggleTheme}
              className="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition flex items-center justify-center"
              title={theme === "dark" ? "Mudar para Modo Claro" : "Mudar para Modo Escuro"}
              aria-label="Alternar entre modo claro e modo escuro"
            >
              {theme === "dark" ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-slate-700" />
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

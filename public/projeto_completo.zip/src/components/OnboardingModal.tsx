import React, { useState } from "react";
import {
  Sparkles,
  Zap,
  FileScan,
  Activity,
  Sliders,
  ShieldCheck,
  HeartHandshake,
  ArrowRight,
  ArrowLeft,
  Check,
  X,
  BookOpen,
} from "lucide-react";
import { AppTab } from "../types";

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToTab: (tab: AppTab) => void;
}

const STEPS = [
  {
    step: 1,
    badge: "Bem-vindo ao Turn OFF",
    title: "Economia Inteligente & Cidadania Elétrica",
    subtitle:
      "Desenvolvido pela equipe GT-02 da EEEP Dom Walfrido Teixeira Vieira para colocar o controle da conta de luz nas suas mãos.",
    icon: Zap,
    color: "emerald",
    bullets: [
      "Auditoria transparente da sua conta de energia (TUSD, TE, Bandeiras tarifárias e Impostos).",
      "Diagnóstico cômodo por cômodo baseado nas leis da física e dados oficiais do Inmetro / Procel.",
      "Simulações de hábitos sem dupla contagem e cálculo de retorno (payback) na compra de novos aparelhos.",
      "Acessibilidade completa com suporte a narração por voz (TTS), alto contraste e linguagem simples.",
    ],
    targetTab: "home" as AppTab,
    btnLabel: "Avançar para o Leitor",
  },
  {
    step: 2,
    badge: "1. Leitor de Fatura com IA",
    title: "Escaneie sua Conta e Entenda Cada Centavo",
    subtitle:
      "Faça upload de uma foto, PDF ou texto da sua conta de energia. O Turn OFF audita o faturamento automaticamente.",
    icon: FileScan,
    color: "blue",
    bullets: [
      "Identifica consumo faturado (kWh), valor total a pagar e tarifas de energia e distribuição.",
      "Detecta automaticamente se a sua conta já possui o benefício da Tarifa Social cadastrado.",
      "Dicionário explicativo interativo para cada imposto (ICMS, PIS, COFINS) e bandeira vigente.",
      "Verificação de coerência: previne erros de digitação e validações inconsistentes.",
    ],
    targetTab: "scanner" as AppTab,
    btnLabel: "Conhecer o Diagnóstico",
  },
  {
    step: 3,
    badge: "2. Diagnóstico Residencial com Modo Foco",
    title: "Descubra Onde Sua Energia Está Sendo Gasta",
    subtitle:
      "Cadastre os aparelhos da sua residência em um fluxo imersivo de 4 passos com validação em tempo real.",
    icon: Activity,
    color: "amber",
    bullets: [
      "Modo Foco que recolhe o menu inferior para digitação sem distrações no celular.",
      "Ar-condicionado com seleção de BTUs (7.000 a 30.000) e tecnologia Inverter com fator de modulação.",
      "Bombas d'água com potência em CV e iluminação dividida cômodo por cômodo (LED, Fluorescente, Incandescente).",
      "Relatório final com gráfico de distribuição, confiabilidade calculada e verificação de riscos elétricos.",
    ],
    targetTab: "diagnosis" as AppTab,
    btnLabel: "Ver Simuladores",
  },
  {
    step: 4,
    badge: "3. Simulador 'E Se?' & Estudo de Payback",
    title: "Teste Cenários Antes de Tomar Decisões",
    subtitle:
      "Descubra quanto você economiza mudando hábitos ou investindo em equipamentos novos mais eficientes.",
    icon: Sliders,
    color: "indigo",
    bullets: [
      "Simulador 'E Se?': 2 opções práticas por aparelho sem dupla contagem e com teto físico realista.",
      "Simulador de Compra & Payback: calcula em quantos meses a compra de um modelo Procel A se paga.",
      "Gráfico interativo de ponto de equilíbrio mostrando a evolução financeira mês a mês.",
      "Compartilhe suas simulações e estudos de investimento diretamente pelo WhatsApp, Telegram ou PDF.",
    ],
    targetTab: "payback" as AppTab,
    btnLabel: "Ver Segurança e Cidadania",
  },
  {
    step: 5,
    badge: "4. Segurança, Cidadania & Tarifa Social",
    title: "Conhecimento e Direitos para Toda a Família",
    subtitle:
      "Segurança da vida em primeiro lugar, aprendizado prático e acesso ao desconto federal de energia.",
    icon: ShieldCheck,
    color: "rose",
    bullets: [
      "Guia de Segurança Elétrica: 6 sinais de perigo imediato, cuidados com disjuntores, DR e tomadas aquecidas.",
      "Tarifa Social (TSEE): regulamentada pela Lei 15.235/2025, com 100% de desconto até 80 kWh/mês para CadÚnico.",
      "Aba de Aprendizado: desmistificação de mitos populares e como fazer a leitura do relógio medidor.",
      "Central de Compartilhamento: envie relatórios, diagnósticos e estudos em texto formatado ou PDF.",
    ],
    targetTab: "safety" as AppTab,
    btnLabel: "Começar a Explorar o App!",
  },
];

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onClose,
  onNavigateToTab,
}) => {
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOpen) return null;

  const data = STEPS[currentStep];
  const isFirst = currentStep === 0;
  const isLast = currentStep === STEPS.length - 1;

  const handleNext = () => {
    if (isLast) {
      onClose();
      onNavigateToTab("home");
    } else {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (!isFirst) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleJumpToTab = (tab: AppTab) => {
    onClose();
    onNavigateToTab(tab);
  };

  const IconComp = data.icon;

  return (
    <div
      id="onboarding-modal-backdrop"
      className="fixed inset-0 z-50 overflow-y-auto p-4 sm:p-6 flex items-start justify-center pt-6 sm:pt-12 pb-16 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="onboarding-modal-container"
        className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border-2 border-slate-300 dark:border-slate-800 overflow-hidden flex flex-col animate-in zoom-in-95 duration-150"
      >
        {/* Header with progress */}
        <div className="p-6 sm:p-8 pb-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-black">
              <IconComp className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                Tutorial do Aplicativo • Passo {currentStep + 1} de {STEPS.length}
              </span>
              <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
                {data.badge}
              </h2>
            </div>
          </div>
          <button
            id="btn-skip-tutorial"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            title="Fechar tutorial"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step progress pills */}
        <div className="px-6 sm:px-8 pt-4 flex gap-1.5">
          {STEPS.map((s, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentStep(idx)}
              className={`h-1.5 rounded-full flex-1 transition-all ${
                idx === currentStep
                  ? "bg-emerald-600 dark:bg-emerald-500"
                  : idx < currentStep
                  ? "bg-emerald-200 dark:bg-emerald-900/60"
                  : "bg-slate-200 dark:bg-slate-800"
              }`}
              title={`Ir para o passo ${idx + 1}`}
            />
          ))}
        </div>

        {/* Body content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 flex-1">
          <div className="space-y-2">
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              {data.title}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {data.subtitle}
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              O que você encontra nesta funcionalidade:
            </h4>
            <ul className="space-y-2.5">
              {data.bullets.map((b, idx) => (
                <li
                  key={idx}
                  className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300"
                >
                  <span className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3 h-3" />
                  </span>
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-6 sm:p-8 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-900/50">
          <div>
            {!isFirst ? (
              <button
                id="btn-tutorial-prev"
                onClick={handlePrev}
                className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition flex items-center gap-1.5"
              >
                <ArrowLeft className="w-4 h-4" />
                Anterior
              </button>
            ) : (
              <button
                id="btn-tutorial-skip-bottom"
                onClick={onClose}
                className="text-xs text-slate-500 dark:text-slate-400 hover:underline font-medium"
              >
                Pular tutorial
              </button>
            )}
          </div>

          <div className="flex items-center gap-3">
            {!isFirst && !isLast && (
              <button
                onClick={() => handleJumpToTab(data.targetTab)}
                className="hidden sm:inline-flex px-3 py-2 rounded-xl text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition"
              >
                Abrir agora
              </button>
            )}
            <button
              id="btn-tutorial-next"
              onClick={handleNext}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold shadow-sm flex items-center gap-2 transition"
            >
              <span>{data.btnLabel}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
